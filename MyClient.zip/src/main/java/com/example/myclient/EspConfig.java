package com.example.myclient;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;

import java.util.Set;

public class EspConfig {
    public static boolean players, mobs;

    public static final Set<Block> BLOCKS = Set.of(
        Blocks.DIAMOND_ORE, Blocks.DEEPSLATE_DIAMOND_ORE,
        Blocks.EMERALD_ORE, Blocks.DEEPSLATE_EMERALD_ORE,
        Blocks.GOLD_ORE, Blocks.DEEPSLATE_GOLD_ORE,
        Blocks.IRON_ORE, Blocks.DEEPSLATE_IRON_ORE,
        Blocks.ANCIENT_DEBRIS, Blocks.CHEST, Blocks.SPAWNER
    );

    public static boolean shouldGlow(Entity e) {
        if (e == MinecraftClient.getInstance().player) return false;
        return (players && e instanceof PlayerEntity)
            || (mobs && e instanceof MobEntity);
    }

    public static int color(Entity e) {
        if (e instanceof PlayerEntity) return 0x00FFFF;
        if (e instanceof Monster) return 0xFF3333;
        return 0x33FF33;
    }
}
