package com.example.myclient.mixin;

import com.example.myclient.EspConfig;
import com.example.myclient.modules.Xray;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.Direction;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Block.class)
public class BlockMixin {
    @Inject(method = "shouldDrawSide", at = @At("HEAD"), cancellable = true)
    private static void myclient$xray(BlockState state, BlockState neighbor,
                                      Direction side, CallbackInfoReturnable<Boolean> cir) {
        if (Xray.ACTIVE) cir.setReturnValue(EspConfig.BLOCKS.contains(state.getBlock()));
    }
}
