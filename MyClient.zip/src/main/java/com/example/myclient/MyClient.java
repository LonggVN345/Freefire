package com.example.myclient;

import com.example.myclient.gui.ClickGuiScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.LinkedHashMap;
import java.util.Map;

public class MyClient implements ClientModInitializer {
    private static final KeyBinding.Category CATEGORY =
        KeyBinding.Category.create(Identifier.of("myclient", "main"));
    private final Map<KeyBinding, Module> binds = new LinkedHashMap<>();
    private KeyBinding openGui;

    @Override
    public void onInitializeClient() {
        int[] defaults = { GLFW.GLFW_KEY_G, GLFW.GLFW_KEY_H, GLFW.GLFW_KEY_J };
        for (int i = 0; i < ModuleManager.MODULES.size(); i++) {
            Module m = ModuleManager.MODULES.get(i);
            int key = i < defaults.length ? defaults[i] : GLFW.GLFW_KEY_UNKNOWN;
            KeyBinding kb = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.myclient." + m.getName().toLowerCase(), key, CATEGORY));
            binds.put(kb, m);
        }

        openGui = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.myclient.gui", GLFW.GLFW_KEY_RIGHT_SHIFT, CATEGORY));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            for (var e : binds.entrySet())
                while (e.getKey().wasPressed()) e.getValue().toggle();
            while (openGui.wasPressed())
                client.setScreen(new ClickGuiScreen());
            if (client.player != null && client.world != null) ModuleManager.tick();
        });
    }
}
