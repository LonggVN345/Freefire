package com.example.myclient.modules;

import com.example.myclient.Module;

public class AutoSprint extends Module {
    public AutoSprint() { super("AutoSprint"); }

    @Override public void onTick() {
        if (mc.options.forwardKey.isPressed()
                && !mc.player.horizontalCollision
                && mc.player.getHungerManager().getFoodLevel() > 6) {
            mc.player.setSprinting(true);
        }
    }
}
