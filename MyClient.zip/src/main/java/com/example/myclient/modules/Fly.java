package com.example.myclient.modules;

import com.example.myclient.Module;

public class Fly extends Module {
    public Fly() { super("Fly"); }

    @Override public void onTick() {
        mc.player.getAbilities().allowFlying = true;
    }

    @Override public void onDisable() {
        if (mc.player == null) return;
        var a = mc.player.getAbilities();
        if (!mc.player.isCreative() && !mc.player.isSpectator()) {
            a.allowFlying = false;
            a.flying = false;
        }
    }
}
