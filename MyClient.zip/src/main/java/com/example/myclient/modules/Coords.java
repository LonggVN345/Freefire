package com.example.myclient.modules;

import com.example.myclient.Module;
import net.minecraft.text.Text;

public class Coords extends Module {
    public Coords() { super("Coords"); }

    @Override public void onTick() {
        var p = mc.player;
        mc.inGameHud.setOverlayMessage(Text.literal(String.format(
            "§fXYZ: §a%.1f %.1f %.1f §7| §f%s",
            p.getX(), p.getY(), p.getZ(), p.getHorizontalFacing().asString())), false);
    }
}
