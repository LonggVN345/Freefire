package com.example.myclient.modules;

import com.example.myclient.Module;

public class AntiAFK extends Module {
    private int ticks;

    public AntiAFK() { super("AntiAFK"); }

    @Override public void onEnable() { ticks = 0; }

    @Override public void onTick() {
        if (++ticks >= 600) {
            ticks = 0;
            if (mc.player.isOnGround()) mc.player.jump();
            mc.player.setYaw(mc.player.getYaw() + 15);
        }
    }
}
