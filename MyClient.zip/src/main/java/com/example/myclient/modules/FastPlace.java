package com.example.myclient.modules;

import com.example.myclient.Module;
import com.example.myclient.mixin.MinecraftClientAccessor;

public class FastPlace extends Module {
    public FastPlace() { super("FastPlace"); }

    @Override public void onTick() {
        ((MinecraftClientAccessor) mc).setItemUseCooldown(0);
    }
}
