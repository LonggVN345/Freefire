package com.example.myclient.modules;

import com.example.myclient.EspConfig;
import com.example.myclient.Module;

public class MobESP extends Module {
    public MobESP() { super("MobESP"); }
    @Override public void onEnable() { EspConfig.mobs = true; }
    @Override public void onDisable() { EspConfig.mobs = false; }
}
