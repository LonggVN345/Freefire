package com.example.myclient.modules;

import com.example.myclient.Module;
import net.minecraft.entity.attribute.EntityAttributes;

public class Step extends Module {
    public Step() { super("Step"); }

    @Override public void onTick() {
        var attr = mc.player.getAttributeInstance(EntityAttributes.STEP_HEIGHT);
        if (attr != null) attr.setBaseValue(2.0);
    }

    @Override public void onDisable() {
        if (mc.player == null) return;
        var attr = mc.player.getAttributeInstance(EntityAttributes.STEP_HEIGHT);
        if (attr != null) attr.setBaseValue(0.6);
    }
}
