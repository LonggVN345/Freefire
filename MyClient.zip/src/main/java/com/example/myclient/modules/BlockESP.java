package com.example.myclient.modules;

import com.example.myclient.EspConfig;
import com.example.myclient.Module;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;

public class BlockESP extends Module {
    private static final int RADIUS = 16;
    private int ticks;
    private String last = "";

    public BlockESP() { super("BlockESP"); }

    @Override public void onTick() {
        if (++ticks % 20 == 0) scan();
        if (!last.isEmpty())
            mc.inGameHud.setOverlayMessage(Text.literal(last), false);
    }

    private void scan() {
        BlockPos origin = mc.player.getBlockPos();
        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;
        for (BlockPos p : BlockPos.iterate(origin.add(-RADIUS, -RADIUS, -RADIUS),
                                           origin.add(RADIUS, RADIUS, RADIUS))) {
            var block = mc.world.getBlockState(p).getBlock();
            if (!EspConfig.BLOCKS.contains(block)) continue;
            double d = p.getSquaredDistance(origin);
            if (d < bestDist) { bestDist = d; best = p.toImmutable(); }
        }
        last = best == null ? "" : String.format("§e%s §f%d %d %d §7(%.0fm)",
            mc.world.getBlockState(best).getBlock().getName().getString(),
            best.getX(), best.getY(), best.getZ(), Math.sqrt(bestDist));
    }
}
