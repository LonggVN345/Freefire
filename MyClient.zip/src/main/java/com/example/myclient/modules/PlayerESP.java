package com.example.myclient.modules;

import com.example.myclient.EspConfig;
import com.example.myclient.Module;

public class PlayerESP extends Module {
    public PlayerESP() { super("PlayerESP"); }
    @Override public void onEnable() { EspConfig.players = true; }
    @Override public void onDisable() { EspConfig.players = false; }
}
