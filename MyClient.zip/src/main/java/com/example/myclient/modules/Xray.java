package com.example.myclient.modules;

import com.example.myclient.Module;

public class Xray extends Module {
    public static boolean ACTIVE;

    public Xray() { super("Xray"); }

    @Override public void onEnable() {
        ACTIVE = true;
        if (mc.worldRenderer != null) mc.worldRenderer.reload();
    }

    @Override public void onDisable() {
        ACTIVE = false;
        if (mc.worldRenderer != null) mc.worldRenderer.reload();
    }
}
