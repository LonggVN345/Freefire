package com.example.myclient.modules;

import com.example.myclient.Module;
import net.minecraft.util.math.Vec3d;

public class Speed extends Module {
    private static final double SPEED = 0.35;

    public Speed() { super("Speed"); }

    @Override public void onTick() {
        var o = mc.options;
        double f = (o.forwardKey.isPressed() ? 1 : 0) - (o.backKey.isPressed() ? 1 : 0);
        double s = (o.leftKey.isPressed() ? 1 : 0) - (o.rightKey.isPressed() ? 1 : 0);
        if ((f == 0 && s == 0) || !mc.player.isOnGround()) return;

        double yaw = Math.toRadians(mc.player.getYaw());
        double sin = Math.sin(yaw), cos = Math.cos(yaw);
        double x = (-sin * f + cos * s);
        double z = (cos * f + sin * s);
        double len = Math.sqrt(x * x + z * z);
        Vec3d v = mc.player.getVelocity();
        mc.player.setVelocity(x / len * SPEED, v.y, z / len * SPEED);
    }
}
