package com.example.myclient.modules;

import com.example.myclient.Module;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

public class NoFall extends Module {
    public NoFall() { super("NoFall"); }

    @Override public void onTick() {
        if (mc.player.fallDistance > 2.5f && !mc.player.isGliding()) {
            mc.player.networkHandler.sendPacket(
                new PlayerMoveC2SPacket.OnGroundOnly(true, mc.player.horizontalCollision));
        }
    }
}
