package com.example.myclient.modules;

import com.example.myclient.Module;

public class AutoWalk extends Module {
    public AutoWalk() { super("AutoWalk"); }

    @Override public void onTick() { mc.options.forwardKey.setPressed(true); }

    @Override public void onDisable() { mc.options.forwardKey.setPressed(false); }
}
