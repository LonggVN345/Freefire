package com.example.myclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

public abstract class Module {
    protected static final MinecraftClient mc = MinecraftClient.getInstance();
    private final String name;
    private boolean enabled;

    public Module(String name) { this.name = name; }

    public String getName() { return name; }
    public boolean isEnabled() { return enabled; }

    public void toggle() {
        enabled = !enabled;
        if (enabled) onEnable(); else onDisable();
        if (mc.player != null)
            mc.player.sendMessage(Text.literal(
                "§7[MyClient] §f" + name + ": " + (enabled ? "§aON" : "§cOFF")), true);
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick() {}
}
