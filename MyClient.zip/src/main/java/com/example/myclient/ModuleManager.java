package com.example.myclient;

import com.example.myclient.modules.*;
import java.util.Arrays;
import java.util.List;

public class ModuleManager {
    public static final List<Module> MODULES = Arrays.asList(
        new Fullbright(), new AutoSprint(), new Fly(),
        new Speed(), new Step(), new NoFall(),
        new AutoWalk(), new AntiAFK(), new Coords(), new FastPlace(),
        new PlayerESP(), new MobESP(), new BlockESP(), new Xray()
    );

    public static void tick() {
        for (Module m : MODULES)
            if (m.isEnabled()) m.onTick();
    }
}
