package com.example.myclient.gui;

import com.example.myclient.Module;
import com.example.myclient.ModuleManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class ClickGuiScreen extends Screen {
    public ClickGuiScreen() { super(Text.literal("MyClient")); }

    private static Text label(Module m) {
        return Text.literal((m.isEnabled() ? "§a" : "§7") + m.getName());
    }

    @Override protected void init() {
        int cols = 3, w = 110, h = 20, gap = 4;
        int startX = (width - (cols * w + (cols - 1) * gap)) / 2;
        int startY = 40;
        int i = 0;
        for (Module m : ModuleManager.MODULES) {
            int x = startX + (i % cols) * (w + gap);
            int y = startY + (i / cols) * (h + gap);
            addDrawableChild(ButtonWidget.builder(label(m), b -> {
                m.toggle();
                b.setMessage(label(m));
            }).dimensions(x, y, w, h).build());
            i++;
        }
    }

    @Override public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, 20, 0xFFFFFFFF);
    }

    @Override public boolean shouldPause() { return false; }
}
